# Minimalist Portfolio

Static portfolio website built with HTML, CSS, and JavaScript.

It is ready for deployment with GitHub Pages.

## Project structure

```text
minimalist-portfolio/
├── index.html
├── style.css
├── script.js
├── .nojekyll
└── README.md
```

## Run locally

You can open `index.html` directly in a browser.

For local development in VS Code:

1. Install the **Live Server** extension.
2. Right-click `index.html`.
3. Select **Open with Live Server**.

## Customize

Edit the following areas in `index.html`:

- Name and title
- About section
- Projects
- Skills
- Email
- GitHub URL
- LinkedIn URL

Replace all `href="#"` project links with real URLs.

## Deploy with GitHub Pages

### Method 1: Upload from the GitHub website

1. Create a new GitHub repository.
2. Upload all files from this folder to the repository root.
3. Open the repository's **Settings**.
4. Go to **Pages**.
5. Under **Build and deployment**, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
6. Save the settings.

GitHub will provide a public URL similar to:

```text
https://yourusername.github.io/repository-name/
```

### Method 2: Git commands

```bash
git init
git add .
git commit -m "Add minimalist portfolio"
git branch -M main
git remote add origin https://github.com/yourusername/repository-name.git
git push -u origin main
```

Then enable GitHub Pages from the repository settings.

## Custom domain

After the site is online:

1. Go to repository **Settings**.
2. Open **Pages**.
3. Enter your domain under **Custom domain**.
4. Update the DNS records at your domain provider.

## Notes

- No backend is required.
- No database is required.
- The theme preference is stored in the browser with `localStorage`.
- The website is responsive and works on desktop and mobile.
